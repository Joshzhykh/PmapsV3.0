package com.example.puertomaps;
import retrofit2;
import retrofit2.http;

public interface ApiService {
    @FormUrlEncoded
    @POST("C:\\xampp\\htdocs\\app_pruebas\\insertar_usuario.php") // URL del script PHP
    Call<Void> agregarUsuario(
            @Field("nombre") String nombre,
            @Field("edad") int edad
    );
}

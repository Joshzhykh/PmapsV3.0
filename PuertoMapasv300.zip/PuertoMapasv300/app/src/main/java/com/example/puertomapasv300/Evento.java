package com.example.puertomapasv300;

import android.net.Uri;

public class Evento {
    private String nombre;
    private String descripcion;
    private String horaInicio;
    private String horaFin;
    private Uri imagenUri;

    // Constructor completo con imagen y horas de inicio y fin
    public Evento(String nombre, String descripcion, String horaInicio, String horaFin, Uri imagenUri) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.imagenUri = imagenUri;
    }

    // Constructor alternativo sin imagen (opcional)
    public Evento(String nombre, String descripcion, String horaInicio, String horaFin) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.horaInicio = horaInicio;
        this.horaFin = horaFin;
        this.imagenUri = null; // Indica que no se incluyó una imagen
    }

    // Getters y Setters para todos los campos
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(String horaInicio) {
        this.horaInicio = horaInicio;
    }

    public String getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(String horaFin) {
        this.horaFin = horaFin;
    }

    public Uri getImagenUri() {
        return imagenUri;
    }

    public void setImagenUri(Uri imagenUri) {
        this.imagenUri = imagenUri;
    }

    // Método para mostrar los detalles del evento como texto
    public String getDetalles() {
        return "Nombre: " + nombre + "\nDescripción: " + descripcion +
                "\nHora de Inicio: " + horaInicio + "\nHora de Fin: " + horaFin +
                (imagenUri != null ? "\nImagen: " + imagenUri.toString() : "\nSin imagen");
    }
}
package com.example.puertomapasv300;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import java.util.Calendar;

public class MainActivity2 extends AppCompatActivity implements OnMapReadyCallback {

    private static final int PICK_IMAGE_REQUEST = 1;

    private GoogleMap mMap;
    private Marker laNubeMarker;
    private Evento eventoLaNube;
    private Button btnAgregarEvento;
    private Uri selectedImageUri;
    private String horaInicio, horaFin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        btnAgregarEvento = findViewById(R.id.button);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        btnAgregarEvento.setOnClickListener(v -> mostrarFormularioEvento());
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        LatLng laNubePosition = new LatLng(-41.469993, -72.941597);
        laNubeMarker = mMap.addMarker(new MarkerOptions().position(laNubePosition).title("La Nube"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(laNubePosition, 14));

        mMap.setOnMarkerClickListener(marker -> {
            if (marker.equals(laNubeMarker) && eventoLaNube != null) {
                mostrarDetallesEvento(eventoLaNube);
                return true;
            }
            return false;
        });
    }

    private void mostrarFormularioEvento() {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_evento, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        EditText txtEventoNombre = bottomSheetView.findViewById(R.id.etTitulo);
        EditText txtEventoDescripcion = bottomSheetView.findViewById(R.id.etDescripcion);
        Button btnHoraInicio = bottomSheetView.findViewById(R.id.btnHoraInicio);
        Button btnHoraFin = bottomSheetView.findViewById(R.id.btnHoraFin);
        Button btnAgregarImagen = bottomSheetView.findViewById(R.id.btnAgregarImagen);
        Button btnGuardarEvento = bottomSheetView.findViewById(R.id.btnGuardar);

        btnHoraInicio.setOnClickListener(v -> seleccionarHora(true));
        btnHoraFin.setOnClickListener(v -> seleccionarHora(false));
        btnAgregarImagen.setOnClickListener(v -> seleccionarImagen());

        btnGuardarEvento.setOnClickListener(v -> {
            String nombreEvento = txtEventoNombre.getText().toString().trim();
            String descripcionEvento = txtEventoDescripcion.getText().toString().trim();

            if (nombreEvento.isEmpty() || descripcionEvento.isEmpty() || horaInicio == null || horaFin == null) {
                Toast.makeText(this, "Por favor, complete todos los campos", Toast.LENGTH_SHORT).show();
                return;
            }

            eventoLaNube = new Evento(nombreEvento, descripcionEvento, horaInicio, horaFin, selectedImageUri);

            Toast.makeText(this, "Evento guardado en 'La Nube'", Toast.LENGTH_SHORT).show();
            bottomSheetDialog.dismiss();
        });

        bottomSheetDialog.show();
    }

    private void seleccionarHora(boolean esHoraInicio) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                (TimePicker view, int hourOfDay, int minuteOfHour) -> {
                    String horaSeleccionada = String.format("%02d:%02d", hourOfDay, minuteOfHour);
                    if (esHoraInicio) {
                        horaInicio = horaSeleccionada;
                    } else {
                        horaFin = horaSeleccionada;
                    }
                }, hour, minute, true);

        timePickerDialog.show();
    }

    private void seleccionarImagen() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            selectedImageUri = data.getData();
            Toast.makeText(this, "Imagen seleccionada", Toast.LENGTH_SHORT).show();
        }
    }

    private void mostrarDetallesEvento(Evento evento) {
        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View bottomSheetView = LayoutInflater.from(this).inflate(R.layout.bottom_sheet_evento_detalles, null);
        bottomSheetDialog.setContentView(bottomSheetView);

        //TextView txtEventoNombre = bottomSheetView.findViewById(tvTitulo);
        TextView txtEventoDescripcion = bottomSheetView.findViewById(R.id.tvDescripcion);
        TextView txtHoraInicio = bottomSheetView.findViewById(R.id.tvHoraInicio);
        TextView txtHoraFin = bottomSheetView.findViewById(R.id.tvHoraFin);
        ImageView imgEvento = bottomSheetView.findViewById(R.id.imgEventoDetalles);

        //txtEventoNombre.setText(evento.getNombre());
        txtEventoDescripcion.setText(evento.getDescripcion());
        txtHoraInicio.setText("Hora de inicio: " + evento.getHoraInicio());
        txtHoraFin.setText("Hora de término: " + evento.getHoraFin());

        if (evento.getImagenUri() != null) {
            imgEvento.setImageURI(evento.getImagenUri());
        }

        bottomSheetDialog.show();
    }
}
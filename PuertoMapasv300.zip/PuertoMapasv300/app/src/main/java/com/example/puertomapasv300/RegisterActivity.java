package com.example.puertomapasv300;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.text.TextUtils;

import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity {
    private EditText editTextName, editTextEmail, editTextAddress, editTextPhone, editTextPassword;
    private Button buttonRegister;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextName = findViewById(R.id.editTextName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextAddress = findViewById(R.id.editTextAddress);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonRegister = findViewById(R.id.buttonRegister);

        mAuth = FirebaseAuth.getInstance();

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }
        });
    }

    private void createAccount() {
        String name = editTextName.getText().toString();
        String email = editTextEmail.getText().toString();
        String address = editTextAddress.getText().toString();
        String phone = editTextPhone.getText().toString();
        String password = editTextPassword.getText().toString();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(email) || TextUtils.isEmpty(address) ||
                TextUtils.isEmpty(phone) || TextUtils.isEmpty(password)) {
            Toast.makeText(RegisterActivity.this, "Por favor, llena todos los campos.", Toast.LENGTH_SHORT).show();
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        Toast.makeText(RegisterActivity.this, "Registro exitoso.", Toast.LENGTH_SHORT).show();
                        // Aquí puedes agregar código para guardar información adicional del usuario
                        // en una base de datos como Firestore o Realtime Database.
                        // Por ejemplo:
                        // FirebaseUser user = mAuth.getCurrentUser();
                        // DatabaseReference database = FirebaseDatabase.getInstance().getReference();
                        // String userId = user.getUid();
                        // User newUser = new User(name, email, address, phone);
                        // database.child("users").child(userId).setValue(newUser);

                        // Navegar a otra actividad si es necesario
                        // Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                        // startActivity(intent);
                        // finish();
                    } else {
                        Toast.makeText(RegisterActivity.this, "Fallo en el registro.", Toast.LENGTH_SHORT).show();
                    }
                });
    }
}